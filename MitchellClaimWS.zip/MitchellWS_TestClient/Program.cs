﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MitchellWS_TestClient.ClaimServiceReference;

namespace MitchellWS_TestClient
{
    class Program
    {
        static void Main(string[] args)
        {
            ClaimServiceReference.ClaimServiceClient claimService = new ClaimServiceClient();
            var result = claimService.ReadClaim("22c9c23bac142856018ce14a26b6c299");
        }
    }
}
