﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.XPath;

namespace MitchellClaimWS
{
    public class ClaimService : IClaimService
    {
        static string strXMLPath = ConfigurationManager.AppSettings["xmlPath"];
        static string strXSDPath = ConfigurationManager.AppSettings["xsdPath"];

        public string CreateClaim(XmlDocument MitchellClaimXML)
        {
            string result = "";
            return result;
        }
        public MitchellClaimType ReadClaim(string claimNumberField)
        {
            // find claim in xml file
            //bool isValidXML = IsValidXml(strXMLPath, "http://www.mitchell.com/examples/claim", strXSDPath);
            MitchellClaimType claimResult = new MitchellClaimType { ClaimNumber = claimNumberField };
            try
            {
                if (File.Exists(strXMLPath))
                {
                    XElement xmlDoc = XElement.Load(strXMLPath);

                    claimResult = XDocument.Load(strXMLPath).Element("Claims")
                            .Descendants("MitchellClaim")
                            .Where(claim => (string)claim.Element("ClaimNumber") ==
                                claimNumberField)
                                .Select(claim => new MitchellClaimType
                                {
                                    ClaimNumber = claim.Element("ClaimNumber").Value,
                                    ClaimantFirstName = claim.Element("ClaimantFirstName").Value,
                                    ClaimantLastName = claim.Element("ClaimantLastName").Value,
                                    Status = (StatusCode)Enum.Parse(typeof(StatusCode), claim.Element("Status").Value),
                                    LossDate = Convert.ToDateTime(claim.Element("LossDate").Value),
                                    LossInfo = (LossInfoType)claim.Descendants("LossInfo").Select(lossInfo => new LossInfoType
                                    {
                                        CauseOfLoss = (CauseOfLossCode)Enum.Parse(typeof(CauseOfLossCode), lossInfo.Element("CauseOfLoss").Value),
                                        ReportedDate = Convert.ToDateTime(lossInfo.Element("ReportedDate").Value),
                                        LossDescription = lossInfo.Element("LossDescription").Value
                                    }).First(),
                                    AssignedAdjusterID = Convert.ToInt64(claim.Element("AssignedAdjusterID").Value)
                                    ,
                                    Vehicles = claim.Element("Vehicles").Descendants("VehicleDetails")//claim.Descendants("Vehicles").Descendants()
                                      .Select(vehicle => new VehicleInfoType
                                      {
                                          Vin = vehicle.Element("Vin").Value,
                                          ModelYear = Convert.ToInt16(vehicle.Element("ModelYear").Value),
                                          MakeDescription = vehicle.Element("MakeDescription").Value,
                                          ModelDescription = vehicle.Element("ModelDescription").Value,
                                          EngineDescription = vehicle.Element("EngineDescription").Value,
                                          ExteriorColor = vehicle.Element("ExteriorColor").Value,
                                          LicPlate = vehicle.Element("LicPlate").Value,
                                          LicPlateState = vehicle.Element("LicPlateState").Value,
                                          LicPlateExpDate = Convert.ToDateTime(vehicle.Element("LicPlateExpDate").Value),
                                          DamageDescription = vehicle.Element("DamageDescription").Value,
                                          Mileage = Convert.ToInt16(vehicle.Element("Mileage").Value)
                                      }).ToList<VehicleInfoType>()
                                }).First();
                }
                return claimResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<MitchellClaimType> GetClaimList(DateTime lossDate1, DateTime lossDate2)
        {
            // find claim in xml file
            List<MitchellClaimType> claimResult = new List<MitchellClaimType>();
            try
            {
                if (File.Exists(strXMLPath))
                {
                    XElement xmlDoc = XElement.Load(strXMLPath);

                    claimResult = XDocument.Load(strXMLPath).Element("Claims")
                            .Descendants("MitchellClaim")
                        //.Where(claim => (string)claim.Element("ClaimNumber") ==
                        //    "22c9c23bac142856018ce14a26b6c299")
                                .Where(claim => (DateTime)claim.Element("LossDate") > lossDate1 &&
                                (DateTime)claim.Element("LossDate") < lossDate2)
                                .Select(claim => new MitchellClaimType
                                {
                                    ClaimNumber = claim.Element("ClaimNumber").Value,
                                    ClaimantFirstName = claim.Element("ClaimantFirstName").Value,
                                    ClaimantLastName = claim.Element("ClaimantLastName").Value,
                                    Status = (StatusCode)Enum.Parse(typeof(StatusCode), claim.Element("Status").Value),
                                    LossDate = Convert.ToDateTime(claim.Element("LossDate").Value),
                                    LossInfo = (LossInfoType)claim.Descendants("LossInfo").Select(lossInfo => new LossInfoType
                                    {
                                        CauseOfLoss = (CauseOfLossCode)Enum.Parse(typeof(CauseOfLossCode), lossInfo.Element("CauseOfLoss").Value),
                                        ReportedDate = Convert.ToDateTime(lossInfo.Element("ReportedDate").Value),
                                        LossDescription = lossInfo.Element("LossDescription").Value
                                    }).First(),
                                    AssignedAdjusterID = Convert.ToInt64(claim.Element("AssignedAdjusterID").Value)
                                    ,
                                    Vehicles = claim.Element("Vehicles").Descendants("VehicleDetails")//claim.Descendants("Vehicles").Descendants()
                                      .Select(vehicle => new VehicleInfoType
                                      {
                                          Vin = vehicle.Element("Vin").Value,
                                          ModelYear = Convert.ToInt16(vehicle.Element("ModelYear").Value),
                                          MakeDescription = vehicle.Element("MakeDescription").Value,
                                          ModelDescription = vehicle.Element("ModelDescription").Value,
                                          EngineDescription = vehicle.Element("EngineDescription").Value,
                                          ExteriorColor = vehicle.Element("ExteriorColor").Value,
                                          LicPlate = vehicle.Element("LicPlate").Value,
                                          LicPlateState = vehicle.Element("LicPlateState").Value,
                                          LicPlateExpDate = Convert.ToDateTime(vehicle.Element("LicPlateExpDate").Value),
                                          DamageDescription = vehicle.Element("DamageDescription").Value,
                                          Mileage = Convert.ToInt16(vehicle.Element("Mileage").Value)
                                      }).ToList<VehicleInfoType>()
                                }).ToList<MitchellClaimType>();
                }
                return claimResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool IsValidXml(string xmlFilePath, string namespaceName, string xsdFilePath)
        {
            Boolean result = true;
            try
            {
                var xdoc = XDocument.Load(xmlFilePath);
                var schemas = new XmlSchemaSet();
                schemas.Add(namespaceName, xsdFilePath);

                xdoc.Validate(schemas, (sender, e) =>
                {
                    result = false;
                });
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }
    }
}
