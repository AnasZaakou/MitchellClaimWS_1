﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Xml;


namespace MitchellClaimWS
{
    [ServiceContract]
    public interface IClaimService
    {
        [OperationContract]
        [WebInvoke(UriTemplate = "/CreateClaim/", Method = "POST", 
            ResponseFormat = WebMessageFormat.Xml, RequestFormat = WebMessageFormat.Xml, BodyStyle = WebMessageBodyStyle.Wrapped)]
        string CreateClaim(XmlDocument MitchellClaimXML);

        [OperationContract]
        [WebGet(UriTemplate = "/GetClaim/{claimNumberField}", ResponseFormat = WebMessageFormat.Xml)]
        MitchellClaimType ReadClaim(string claimNumberField);

        [OperationContract]
        [WebGet(UriTemplate = "/GetClaimList?lossDate1={lossDate1}&lossDate2={lossDate2}", ResponseFormat = WebMessageFormat.Xml)]
        List<MitchellClaimType> GetClaimList(DateTime lossDate1, DateTime lossDate2);
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
}
